﻿=== Integraimob ===
Contributors: Lucas Silveira
Tags: integração imóveis, integração olx, integração viva real, integração zap imóveis, integração Imóvel Web

Sistema de integração de sites imobiliários com os principais portais de imóveis.

== Description ==
Sistema de integração de sites imobiliários com os principais portais de imóveis.

== Installation ==
1. Envie os arquivos do plugin para o diretório \"/wp-content /plugins/plugin-name\", ou instale o plugin através da tela de plugins do WordPress diretamente.
1. Ative o plugin através da tela \'Plugins\' no WordPress
1. Use a tela Configurações-> Integraimob para configurar o plugin

== Changelog ==

= 1.0 =
* Criação dos arquivos e funções do plugin.